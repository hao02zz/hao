<?php

$mysqli = new mysqli('localhost', 'root', '092265', 'badminton');
if (isset($_GET['date'])) {
    $date = $_GET['date'];
    $stmt = $mysqli->prepare("select * from bookings where date = ?");
    $stmt->bind_param('s', $date);
    $bookings = array();
    if ($stmt->execute()) {
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $bookings[] = $row['timeslot'];
            }

            $stmt->close();
        }
    }
}

session_start(); // start the session

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $timeslot = $_POST['timeslot'];
    $status = $_POST['status'] ?? "pending";
    $amount = $_POST['amount'] ?? "Rm20";

    $filename = $_FILES["file"]["name"];
    $target_file = "upload/" . $filename;
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

    move_uploaded_file($_FILES["file"]["name"], "upload/" . $filename);

    $stmt = $mysqli->prepare("INSERT INTO bookings (date, name, email, timeslot,status,amount,filename) VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param('sssssss', $date, $name, $email, $timeslot, $status, $amount, $filename);
    $stmt->execute();

    $_SESSION['message'] = "Booking Successful"; // store success message in session variable
    $_SESSION['bookings'][] = $timeslot; // add booked timeslot to session variable

    // redirect to receipt page
    header('location: test.php');
    exit();


$stmt->close();
$mysqli->close();
}

$duration = 60;
$cleanup = 0;
$start = "12:00";
$end = "24:00";

function timeslots($duration, $cleanup, $start, $end)
{
    $start = new DateTime($start);
    $end = new DateTime($end);
    $interval = new DateInterval("PT" . $duration . "M");
    $cleanupInterval = new DateInterval("PT" . $cleanup . "M");
    $slots = array();

    for ($intStart = $start; $intStart < $end; $intStart->add($interval)->add($cleanupInterval)) {
        $endPeriod = clone $intStart;
        $endPeriod->add($interval);
        if ($endPeriod > $end) {
            break;
        }

        $slots[] = $intStart->format("H:iA") . "-" . $endPeriod->format("H:iA");
    }

    return $slots;
}


?>
<!doctype html>
<html lang="en">

<head>
    <title>Booking</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title></title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/style.css">
</head>

<body>
    <div class="container">
        <a href="booking.php" class="btn btn-primary py-md-2 px-md-4 ">Back</a>
        <h1 class="text-center">(Court 1)</h1>
        <hr>
        <h2 class="text-center">(RM 20 for one hour)</h2>
        <hr>
        <div class="row">
            <div class="col-md-12">
                <?php echo isset($msg) ? $msg : ""; ?>
            </div>
            <?php $timeslots = timeslots($duration, $cleanup, $start, $end);
            foreach ($timeslots as $ts) {
            ?>
                <div class="col-md-2">
                    <div class="form-group">
                        <?php if (in_array($ts, $bookings)) { ?>
                            <button class="btn btn-danger"><?php echo $ts; ?></button>
                        <?php } else { ?>
                            <button class="btn btn-success book" data-timeslot="<?php echo $ts; ?>"><?php echo $ts;
                                                                                                    ?></button>
                        <?php } ?>
                    </div>


                </div>

            <?php } ?>

            <div id="myModal" class="modal fade" role="dialog">
                <div class="modal-dialog">

                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Booking: <span id="slot"></span></h4>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <form action="" method="post" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <label for="">Timeslot</label>
                                            <input required type="text" readonly name="timeslot" id="timeslot" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="">Name</label>
                                            <input required type="text" name="name" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="">Email</label>
                                            <input required type="text" name="email" class="form-control">
                                        </div>



                                        <div class="input-group">

                                            <div class="input-box">
                                                <h4>Payment Details</h4>
                                                <label for="bc2"><span><i class="fa fa-google-wallet"></i></i>Tng E-wallet</span></label>
                                            </div>
                                        </div>
                                        <img class src="img/tng.png" alt="Image" width="250" height="350"><br>

                                        Select file to upload:<br>
                                        <input type="file" name="file" id="file" require><br>


                                        <div class="form-group">
                                            <button button class="btn btn-primary" type="submit" name="submit">Submit</button></a>
                                        </div>
                                    </form>

                                </div>
                            </div>


                        </div>
                    </div>


                    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
                    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
                    <script>
                        $(".book").click(function() {
                            var timeslot = $(this).attr('data-timeslot');
                            $("#slot").html(timeslot);
                            $("#timeslot").val(timeslot);
                            $("#myModal").modal("show");
                        })
                    </script>
</body>


</body>

</html>
