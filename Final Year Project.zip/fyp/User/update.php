<?php
require('db.php');
$id=$_GET['updateid'];
$sql="select * from `bookings` where id=$id";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_assoc($result);

$name=$row['name'];
$email=$row['email'];
$status=$row['status'];


if(isset($_POST['submit'])){
    
    $name=$_POST['name'];
    $email=$_POST['email'];
    $status=$_POST['status'];
    

    $sql="update `bookings` set name='$name',
    email='$email',status='$status' WHERE id='$id'";
    $result=mysqli_query($con,$sql);
    if($result){
        echo"update successfully";
        header('location:adminhomepage.php');
    }else{
        die(mysqli_error($con));
    }
}
?>

<!doctype html>
<html lang="en">
<title>Admin Update</title>
<body>

<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
        <div class="modal-header">
            
            
   
    <link rel="stylesheet" href="css/style.css"/>
</head>
        </div>
        
        <form class="form" method="post" name="login">
        <h1 class="login-title">Update</h1>
            <div class="form-group">
            <label for="">Name</label>
            <input required type="text" name="name"class="login-input">
        </div>
            <div class="form-group">
            <label for="">Email</label>
            <input required type="text" name="email"class="login-input">
            <div class="form-group">
            <label for="">Status</label>
            <input required type="text" name="status"class="login-input">
            </div>
        
            <div class="form-group">
            <button class="login-button"type="submit"name="submit">Submit</button>
            <p class="link"><a href="adminhomepage.php">Back</a></p>
            </div>
            
        </form>
        
        </div>
        </div>
        
        </div>

    </div>
    </div>
  
    </body>

</html>