<?php
    require('db.php');
    session_start()
?>
    
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

</head>
<body>

<div class="container-fluid bg-dark px-0">
        <div class="row gx-0">
            <div class="col-lg-3 bg-dark ">
                <a href="receipt.php" class="navbar-brand w-250 h-100 m-0 p-0 d-flex align-items-center justify-content-center">
                    <h1 class="m-0 display-5 text-primary text-uppercase">Order</h1>
                </a>
                
            </div>
            <div class="navbar-nav mr-auto py-0">
            </div>
            <a href="receipt.php" class="btn btn-primary py-md-3 px-md-5 ">back</a>
            <a href="index.html" class="btn btn-primary py-md-3 px-md-5 ">Log Out</a>
            </div>
        </div>
        
        </div>
    </div>

<div class="container">

<table class="table">
  <thread>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Date</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Timeslot</th>
      <th scope="col">Status</th>
      <th scope="col">Amount</th>
      <th scope="col">File</th>
    </tr>
  </thread>
  <tbody>

  <?php
  $sql ="select * from `bookings` where userID = ".$_SESSION['userID'];
  $result=mysqli_query($con,$sql);
  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["id"]. "</td><td>" . $row["date"]. "</td><td>" . $row["name"]. "</td><td>"
        . $row["email"]. "</td><td>". $row["timeslot"]. "</td><td>". $row["status"]. "</td><td>". $row["amount"]."</td><td>" 
        . $row["filename"]."</td></tr>" ;
        $filename = 'upload/'.$row["filename"];
    }
} else {
    echo "0 results";
}
?>

   

 
</table>
</div>
  
</body>

</html>