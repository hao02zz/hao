<?php
    require('db.php');
?>
    
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

</head>
<body>

<div class="container-fluid bg-dark px-0">
        <div class="row gx-0">
            <div class="col-lg-3 bg-dark ">
                <a href="index.html" class="navbar-brand w-250 h-100 m-0 p-0 d-flex align-items-center justify-content-center">
                    <h1 class="m-0 display-5 text-primary text-uppercase">Admin Page</h1>
                </a>
            </div>
            <div class="col-lg-9">
                <div class="row gx-0 bg-secondary d-none d-lg-flex">
                
                                                                             
                </div>
                <nav class="navbar navbar-expand-lg bg-dark navbar-dark p-3 p-lg-0 px-lg-5">
                    
                    <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                   
                        <div class="navbar-nav mr-auto py-0">
                            
                            
                          
                        </div>
                        <a href="adminlogin.php" class="btn btn-primary py-md-2 px-md-4 ">Log Out</a>
                    </div>
                </nav>
            </div>
        </div>
    </div>

<div class="container">
<button class="btn btn-primary my-5"><a href="booking.php"class="text-light">Add Booking</a>
</button>
<table class="table">
  
    
      <th scope="col">ID</th>
      <th scope="col">Date</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Timeslot</th>
      <th scope="col">Status</th>
      <th scope="col">Amount</th>
      <th scope="col">FileName</th>
   

  <?php
  $sql ="select * from `bookings`";
  $result=mysqli_query($con,$sql);
  if($result){   
    while($row=mysqli_fetch_assoc($result)){
      $id=$row['id'];
      $date=$row['date'];
      $name=$row['name'];
      $email=$row['email'];
      $timeslot=$row['timeslot'];
      $status=$row['status'];
      $amount=$row['amount'];
      $filename=$row['filename'];
        
      echo '<tr>
      <th scope="row">'.$id.'</th>
      <td>'.$date.'</td>
      <td>'.$name.'</td>
      <td>'.$email.'</td>
      <td>'.$timeslot.'</td>
      <td>'.$status.'</td>
      <td>'.$amount.'</td>
      <td>  
      <img src="upload/'.$row['filename'].'" height="200" width="200" class="img-thumnail" />  
      </td> 
      
      <td>
    <button class="btn btn-primary"><a href="update.php? updateid='.$id.'" class="text-light">Update</a></button>
    <button class="btn btn-danger"><a href="delete.php? deleteid='.$id.'" class="text-light">Delete</a></button>
    </td>
    </tr>';
 
    }
  }

  
?>

 
</table>
</div>
  
</body>
</html>
