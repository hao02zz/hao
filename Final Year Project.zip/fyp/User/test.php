<?php
session_start(); // start the session
echo $_SESSION['userID'].'yhy';
// check if success message and booked timeslots are set in session variables
if (isset($_SESSION['message'])) {
    echo "<div class='alert alert-success'>" . $_SESSION['message'] . "</div>";
}

if (isset($_SESSION['bookings'])) {
    echo "<p>You have booked the following timeslots:</p>";
    echo "<ul>";
    foreach ($_SESSION['bookings'] as $timeslot) {
        echo "<li>" . $timeslot . "</li>";
    }
    echo "</ul>";
}

echo date('Y/d/m H.i.s',time());
// clear session variables
unset($_SESSION['message']);
unset($_SESSION['bookings']);
?>